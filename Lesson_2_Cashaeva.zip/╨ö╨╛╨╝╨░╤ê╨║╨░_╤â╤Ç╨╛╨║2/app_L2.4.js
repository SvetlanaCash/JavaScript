"use strict";
function addition(a, b) {
    return a + b;
}
alert("Сложение: " + addition(5, 3));

function subtraction(a, b) {
    return a - b;
}
alert("Вычитание: " + subtraction(5, 3));

function multiplication(a, b) {
    return a * b;
}
alert("Умножение: " + multiplication(5, 3));

function dividing(a, b) {
    return a / b;
}
alert("Деление: " + dividing(5, 3));