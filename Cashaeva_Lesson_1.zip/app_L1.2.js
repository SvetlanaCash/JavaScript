"use strict"
let name = "Василий";
let admin = name;
console.log(admin);