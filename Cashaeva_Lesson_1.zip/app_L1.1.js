"use strict"
let Tc = -8;
let Tf = ((9 / 5) * Tc + 32);
alert("За окном температура в F " + Tf + " Одевайтесь теплее!");